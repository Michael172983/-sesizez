# Cum contribui?

Nu trebui sa fi programator pentru a contribui, un cont de Github este suficient. Astea sunt cateva feluri in care poti sa contribui:

- Adauga un Issue nou daca ai idei de imbunatatire a aplicatiei, mail-uri ale autoritatilor (din orice localitate!) sau template-uri pentru sesizari
- Verifica ce e in Issues si adauga un nou PR pentru a le rezolva

Limba pentru comunicare pe Github este limba romana (sau romgleza, whatever) iar variabilele pot fi in romana sau engleza, preferabil in engleza.

[Hai pe Discord ca sa colaboram mai eficient!](https://discord.gg/qSqZ9PaqQY)
