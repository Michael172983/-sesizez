export const BRIGADA_RUTIERA = {
  'Bucharest - Sector 1': ['bpr@b.politiaromana.ro'],
  'Bucharest - Sector 2': ['bpr@b.politiaromana.ro'],
  'Bucharest - Sector 3': ['bpr@b.politiaromana.ro'],
  'Bucharest - Sector 4': ['bpr@b.politiaromana.ro'],
  'Bucharest - Sector 5': ['bpr@b.politiaromana.ro'],
  'Bucharest - Sector 6': ['bpr@b.politiaromana.ro'],
}