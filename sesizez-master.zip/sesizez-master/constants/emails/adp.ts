export const ADP = {
  'Bucharest - Sector 1': ['secretariat@adp-sector1.ro'],
  'Bucharest - Sector 2': ['office@adp2.ro'],
  'Bucharest - Sector 3': ['domeniu.public@primarie3.ro'],
  'Bucharest - Sector 4': ['info@adp4.ro', 'info@totulverde.ro'],
  'Bucharest - Sector 5': ['dadp@sector5.ro'],
  'Bucharest - Sector 6': ['contact@adps6.ro'],
  'Iași - Iași': ['contact@djadp.ro'],
  'Craiova - Dolj': ['office@raadpflcraiova.ro'],
  'Cluj-Napoca - Cluj': ['office@radpcj.ro'],
}