export const TRANSPORT_DE_SUPRAFATA = {
  'Bucharest - Sector 1': ['info@stbsa.ro'],
  'Bucharest - Sector 2': ['info@stbsa.ro'],
  'Bucharest - Sector 3': ['info@stbsa.ro'],
  'Bucharest - Sector 4': ['info@stbsa.ro'],
  'Bucharest - Sector 5': ['info@stbsa.ro'],
  'Bucharest - Sector 6': ['info@stbsa.ro'],
  'Iași - Iași': ['pr@sctpiasi.ro'],
  'Craiova - Dolj': ['office@rat-craiova.ro'],
  'Cluj-Napoca - Cluj': ['sugestii@ctpcj.ro'],
}