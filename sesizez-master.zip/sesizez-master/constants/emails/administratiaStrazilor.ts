export const ADMINISTRATIA_STRAZILOR = {
  'Bucharest - Sector 1': ['office@aspmb.ro'],
  'Bucharest - Sector 2': ['office@aspmb.ro'],
  'Bucharest - Sector 3': ['office@aspmb.ro'],
  'Bucharest - Sector 4': ['office@aspmb.ro'],
  'Bucharest - Sector 5': ['office@aspmb.ro'],
  'Bucharest - Sector 6': ['office@aspmb.ro'],
  'Iași - Iași': ['office@citadinis.ro'],
  'Craiova - Dolj': ['office@raadpflcraiova.ro'],
  'Cluj-Napoca - Cluj': ['administrarecaipublice@primariaclujnapoca.ro'],
}