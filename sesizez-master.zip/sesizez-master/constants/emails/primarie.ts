export const PRIMARIE = {
  'Bucharest - Sector 1': ['registratura@primarias1.ro'],
  'Bucharest - Sector 2': ['infopublice@ps2.ro'],
  'Bucharest - Sector 3': ['relatiipublice@primarie3.ro'],
  'Bucharest - Sector 4': ['contact@ps4.ro'],
  'Bucharest - Sector 5': ['sesizari@sector5.ro'],
  'Bucharest - Sector 6': ['prim6@primarie6.ro'],
  'Iași - Iași': ['cabinet.primar@primaria-iasi.ro', 'informatii@primaria-iasi.ro'],
  'Craiova - Dolj': ['relatiicupublicul@primariacraiova.ro'],
  'Cluj-Napoca - Cluj': ['registratura@primariaclujnapoca.ro'],
}