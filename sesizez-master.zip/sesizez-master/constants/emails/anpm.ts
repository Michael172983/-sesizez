export const ANPM = {
  'Bucharest - Sector 1': ['office@anpm.ro', 'office@apmbuc.anpm.ro'],
  'Bucharest - Sector 2': ['office@anpm.ro', 'office@apmbuc.anpm.ro'],
  'Bucharest - Sector 3': ['office@anpm.ro', 'office@apmbuc.anpm.ro'],
  'Bucharest - Sector 4': ['office@anpm.ro', 'office@apmbuc.anpm.ro'],
  'Bucharest - Sector 5': ['office@anpm.ro', 'office@apmbuc.anpm.ro'],
  'Bucharest - Sector 6': ['office@anpm.ro', 'office@apmbuc.anpm.ro'],
  'Iași - Iași': ['office@anpm.ro'],
  'Craiova - Dolj': ['office@anpm.ro'],
  'Cluj-Napoca - Cluj': ['office@anpm.ro'],
}