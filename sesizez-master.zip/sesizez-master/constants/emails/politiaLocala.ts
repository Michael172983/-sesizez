export const POLITIA_LOCALA = {
  'Bucharest - Sector 1': ['contact@politialocalasector1.ro'],
  'Bucharest - Sector 2': ['office@politialocalas2.ro'],
  'Bucharest - Sector 3': ['secretariat@politialocala3.ro'],
  'Bucharest - Sector 4': ['sesizari@politialocala4.ro'],
  'Bucharest - Sector 5': ['politialocala@sector5.ro'],
  'Bucharest - Sector 6': ['office@politia6.ro'],
  'Iași - Iași': ['politialocalais@yahoo.com', 'contact@politialocala-iasi.ro'],
  'Craiova - Dolj': ['office@politialocalacraiova.ro'],
  'Cluj-Napoca - Cluj': ['politialocala@primariaclujnapoca.ro'],
}