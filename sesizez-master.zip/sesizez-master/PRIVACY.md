# Privacy Policy

## We don't collect any data
No analytics software is used in the Sesizez app, and none of your personal data leaves your device through the Sesizez app. The Sesizez app collects the following data points, locally, without sending them to any server: your full name, your address for correspondence, your current location. These data points are then used to generate an email based on a template, and you may choose to send the email to anyone as it no longer takes place in our app.
